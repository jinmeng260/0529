# Exchange 2010 plugins

These are a collection of plugins used by Nagios to monitor Exhange 2010.

## Run tests

Run the test suite from project root with:

```
$ nosetests
```

